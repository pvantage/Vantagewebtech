<?php
require_once('wp-config.php');
$to      = 	'rinku.vantage@gmail.com';	
$subject = get_option('blogname').' : Email 1';	
$from = get_option('admin_email');
$fromname=get_option('blogname');
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= "Content-type: text/html; charset=utf-8" . "\r\nFrom: $fromname <$from>\r\nReply-To: $from";

$message="Dear <br /><br />Thank you for contacting us regarding your lost password. Your password has been reset to , please log in and change the password to something more memorable.<br />";
$message.='<br />Thanks';

wp_mail($to, $subject, $message, $headers);

