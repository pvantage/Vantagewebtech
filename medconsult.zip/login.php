<?php

//@header('Access-Control-Allow-Origin: http://temples.puyangan.com');
@ob_start();
require_once( 'wp-config.php' );

$usererrors=array();
function checkWPFieldexist2($field,$value,$cnd='')
{
	global $wpdb;
	$prefix=$wpdb->base_prefix;
	$sql="select $field, ID from ".$prefix."users where $field='$value' $cnd";
	$sqls= str_replace("' or", ' ',$sql);
	$data = $wpdb->get_results($sqls, OBJECT);
	return $data;
}
$redirect=$_REQUEST['redirect'];
$usr=$_REQUEST['usr'];
$pwd=$_REQUEST['pwd'];
if(trim($usr)=='')
{
	array_push($usererrors,'Please enter username.');
}
if(trim($pwd)=='')
{
	array_push($usererrors,'Please enter password.');
}
if(count($usererrors)<=0)
{
	$check=checkWPFieldexist2('user_login',$usr);
	
	$loginerror=false;
	if(count($check)<=0){$loginerror=true;}
	
	$user = get_user_by( 'login', $usr);
	if ( $user && wp_check_password( $pwd, $user->data->user_pass, $user->ID) ){}else{$loginerror=true;}

	
	$uid=$check[0]->ID;
	if($loginerror)
	{
		array_push($usererrors,'Login detail is wrong.');
	}
	if(count($usererrors)<=0)
	{
		wp_clear_auth_cookie();
		wp_set_auth_cookie($uid);
	}
}
$url='http://www.puyangan.com/'.$redirect;
wp_redirect($url);