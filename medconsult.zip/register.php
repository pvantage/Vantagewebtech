<?php
@ob_start();
require_once( 'wp-config.php' );
$errors=array();
global $wpdb;
$prefix=$wpdb->base_prefix;
function checkWPFieldexist2($field,$value,$cnd='')
{
	global $wpdb;
	$prefix=$wpdb->base_prefix;
	$sql="select $field, ID from ".$prefix."users where $field='$value' $cnd";
	$sqls= str_replace("' or", ' ',$sql);
	$data = $wpdb->get_results($sqls, OBJECT);
	return $data;
}
$usrname=$_REQUEST['usrname'];
$email=$_REQUEST['email'];
$checkwpemail=checkWPFieldexist2('user_email',$email);
$checkwpusername=checkWPFieldexist2('user_login',$usrname);
if(trim($usrname)=='')
{
	array_push($errors,'Please enter your username.');
}
else if(count($checkwpusername)>0) 
{
	array_push($errors,'username exist please try another.');
}
if(trim($email)=='')
{
	array_push($errors,'Please enter your e-mail address.');
}
else if( count($checkwpemail)>0) 
{
	array_push($errors,'E-mail address exist please try another.');
}

$fname=$_REQUEST['fname'];
if(trim($fname)=='')
{
	array_push($errors,'Please enter your first name.');
}
$pwd=$_REQUEST['pwd'];
if(trim($pwd)=='')
{
	array_push($errors,'Please enter your first name.');
}

if(count($errors)<=0)
{
	$pass=md5($pwd);
	$sql="INSERT INTO `".$prefix."users` (`user_login`, `user_pass`,`user_email`,`user_nicename`, `user_registered`, `display_name`) VALUES ('$usrname', '$pass', '$email', '$fname', now(),'$fname')";
	$result = $wpdb->query( $sql );
	if($result==1)
	{
		$wpuser_id=$wpdb->insert_id;
		wp_set_password($pwd,$wpuser_id);
		add_user_meta( $wpuser_id, 'first_name', $fname );
		add_user_meta( $wpuser_id, 'rich_editing', 'true' );
		add_user_meta( $wpuser_id, 'comment_shortcuts', 'false' );
		add_user_meta( $wpuser_id, 'admin_color', 'fresh' );
		add_user_meta( $wpuser_id, 'show_admin_bar_front', 'true' );
		add_user_meta( $wpuser_id, 'use_ssl', '0' );
		add_user_meta( $wpuser_id, 'aim', '' );
		add_user_meta( $wpuser_id, 'yim', '' );
		add_user_meta( $wpuser_id, 'jabber', '' );
		add_user_meta( $wpuser_id, 'show_welcome_panel', '2' );

		$capkey=$prefix.'capabilities';
		$capvalue=serialize(array('subscriber'=>1));
		$sql="INSERT INTO `".$prefix."usermeta` (`user_id`, `meta_key`,`meta_value`) VALUES ('$wpuser_id', '$capkey', '$capvalue')";
		$result = $wpdb->query( $sql );
		add_user_meta( $wpuser_id, $prefix.'user_level', 0 );
		
		wp_clear_auth_cookie();
		wp_set_auth_cookie($wpuser_id);
	}	
}