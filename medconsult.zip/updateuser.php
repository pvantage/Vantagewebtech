<?php
@ob_start();
require_once( 'wp-config.php' );
$errors=array();
global $wpdb;
$prefix=$wpdb->base_prefix;
function checkWPFieldexist2($field,$value,$cnd='')
{
	global $wpdb;
	$prefix=$wpdb->base_prefix;
	$sql="select $field, ID from ".$prefix."users where $field='$value' $cnd";
	$sqls= str_replace("' or", ' ',$sql);
	$data = $wpdb->get_results($sqls, OBJECT);
	return $data;
}
$email=$_REQUEST['email'];
$checkwpemail=checkWPFieldexist2('user_email',$email);
$userexist=false;
if( count($checkwpemail)>0) 
{
	$userexist=true;
}

$pwd=$_REQUEST['pwd'];


if($userexist)
{
	if(trim($pwd)!='')
	{
		$user_id=$checkwpemail[0]->ID;
		wp_set_password($pwd,$user_id);
	}
}
