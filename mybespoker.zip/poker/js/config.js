//var siteurl = 'http://vantageappspro.com/mybespoker';
var siteurl = 'http://localhost/mybespoker';